Запуск проекта:
```
nvm use
npm ci
npm run start
```

*Запрещено изменять содержимое:* src/*, test/*, package.json
